const products=[
  ["Lay's Chips","Snacks",8,20,3,"Yes",87],
  ["Coca-Cola 500ml","Beverages",12,15,3,"Yes",85],
  ["Milk 1L","Dairy",15,18,2,"No",76],
  ["Detergent Powder","Household",20,15,5,"No",68],
  ["Cooking Oil 1L","Cooking",30,22,5,"Yes",61]
];
const tbody=document.getElementById("riskRows");
products.forEach((p,i)=>{
  const tr=document.createElement("tr");
  tr.innerHTML=`<td>${i+1}</td><td>2025-04-${30-i}</td><td>S0${23-i*6}</td><td>P${1042-i*83}</td><td>${p[0]}</td><td>${p[1]}</td><td>${p[2]}</td><td>${p[3]}</td><td>${p[4]}</td><td>${p[5]}</td><td><b style="color:${p[6]>=76?'#e72c43':'#df8c12'}">${p[6]}%</b></td><td><span class="${p[6]>=76?'risk-high':'risk-medium'}">${p[6]>=76?'High':'Medium'}</span></td>`;
  tbody.appendChild(tr);
});

new Chart(document.getElementById("donut"),{
 type:"doughnut",data:{labels:["Low Risk","Medium Risk","High Risk"],datasets:[{data:[62.3,24.7,13]}]},
 options:{cutout:"68%",plugins:{legend:{display:false}},responsive:true,maintainAspectRatio:false}
});
new Chart(document.getElementById("trend"),{
 type:"line",data:{labels:["Apr 24","Apr 25","Apr 26","Apr 27","Apr 28","Apr 29","Apr 30"],datasets:[
 {label:"High",data:[15,15,10,10,9,8,10],borderColor:"#ed3148",tension:.35,pointRadius:3},
 {label:"Medium",data:[33,32,26,27,26,21,23],borderColor:"#f1a51b",tension:.35,pointRadius:3},
 {label:"Low",data:[88,78,65,65,62,50,42],borderColor:"#15966a",tension:.35,pointRadius:3}
]},options:{scales:{y:{beginAtZero:true,max:100,ticks:{callback:v=>v+"%"}}},plugins:{legend:{position:"top"}}}
});
new Chart(document.getElementById("importance"),{
 type:"bar",data:{labels:["Current Stock","Units Sold","Avg. Daily Demand","Lead Time","Promotion Active","Price","Discount %","Day of Week","Month","Category"],datasets:[{data:[.22,.18,.15,.12,.09,.08,.07,.05,.04,.03]}]},
 options:{indexAxis:"y",plugins:{legend:{display:false}},scales:{x:{beginAtZero:true,max:.25}}}
});
function predictRisk(){
  const stock=+document.getElementById("stock").value||0;
  const demand=+document.getElementById("demand").value||1;
  const lead=+document.getElementById("lead").value||1;
  const promo=document.getElementById("promo").value==="Yes";
  const discount=+document.getElementById("discount").value||0;
  const coverage=stock/(demand*lead);
  let risk=55 + (1-Math.min(coverage,1))*30 + (promo?5:0) + Math.min(discount,20)*.25;
  risk=Math.max(3,Math.min(98,Math.round(risk)));
  const level=risk>=70?"HIGH":risk>=40?"MEDIUM":"LOW";
  document.getElementById("probText").textContent=risk+"%";
  document.getElementById("probSide").textContent=risk+"%";
  document.getElementById("riskLabel").textContent=level;
  document.getElementById("recommendation").textContent=level==="HIGH"?"Reorder Suggested":level==="MEDIUM"?"Review Reorder":"Monitor Stock";
  document.querySelector(".gauge").style.background=`conic-gradient(#ed3148 0 ${risk}%,#f7e4e7 ${risk}% 100%)`;
}
